from django.db import models

class ClassRoom(models.Model):
    class_name = models.CharField('ClassRoom Name', max_length=30)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.class_name

class Coures(models.Model):
    course_name = models.CharField('Coures Name', max_length=120)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.course_name

class Teacher(models.Model):
    name = models.CharField('Name', max_length=120)
    gender = models.CharField('Gender', max_length=20)
    email = models.CharField('Email Address', max_length=120)
    description = models.TextField(blank=True)
    classRooms = models.ManyToManyField(ClassRoom, blank=False)
    courses = models.ManyToManyField(Coures, blank=False)
        
    def __str__(self):
        return self.name

class Student(models.Model):
    name = models.CharField('Name', max_length=120)
    gender = models.CharField('Gender', max_length=20)
    email = models.CharField('Email Address', max_length=120)
    classRoom = models.ForeignKey(ClassRoom, blank=False, null=False, on_delete=models.CASCADE)
    description = models.TextField(blank=True)
    teachers = models.ManyToManyField(Teacher, blank=False)
    courses = models.ManyToManyField(Coures, blank=False)
        
    def __str__(self):
        return self.name