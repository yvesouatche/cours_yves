from django.shortcuts import render, redirect
from .models import Student, Coures, ClassRoom, Teacher
from .forms import ClassRoomForm, CourseForm, TeacherForm, StudentForm
from django.http import  HttpResponseRedirect

def home(request):
    return render(request, 'students/home.html', {})

def add_classroom(request):
    submitted = False
    if request.method == "POST":
        form = ClassRoomForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_classroom?submitted=True')
    else:
        form = ClassRoomForm
        if 'submitted' in request.GET:
            submitted=True
    return render(request, 'students/add_classroom.html', {
        'form': form,
        'submitted': submitted,
    })

def add_course(request):
    submitted = False
    if request.method == "POST":
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_course?submitted=True')
    else:
        form = CourseForm
        if 'submitted' in request.GET:
            submitted=True
    return render(request, 'students/add_course.html', {
        'form': form,
        'submitted': submitted,
    })

def teachers_list(request):
    teachers = Teacher.objects.all().order_by('name')
    return render(request, 'students/teachers_list.html', {
        'teachers': teachers,
    })


def add_teacher(request):
    submitted = False
    if request.method == "POST":
        form = TeacherForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_teacher?submitted=True')
    else:
        form = TeacherForm
        if 'submitted' in request.GET:
            submitted=True
    return render(request, 'students/add_teacher.html', {
        'form': form,
        'submitted': submitted,
    })

def delete_teacher(request, teacher_id):
    teacher = Teacher.objects.get(pk=teacher_id)
    teacher.delete()
    return redirect('teachers-list')

def update_teacher(request, teacher_id):
    teacher = Teacher.objects.get(pk=teacher_id)
    form = TeacherForm(request.POST or None, instance=teacher)
    if form.is_valid():
        form.save()
        return redirect('teachers-list')
    return render(request, 'students/update_teacher.html', {
        'teacher': teacher,
        'form': form,
    }) 

def show_teacher(request, teacher_id):
    teacher = Teacher.objects.get(pk=teacher_id)
    return render(request, 'students/show_teacher.html', {
        'teacher': teacher,
    })


def add_student(request):
    submitted = False
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_student?submitted=True')
    else:
        form = StudentForm
        if 'submitted' in request.GET:
            submitted=True
    return render(request, 'students/add_student.html', {
        'form': form,
        'submitted': submitted,
    })

def update_student(request, student_id):
    student = Student.objects.get(pk=student_id)
    form = StudentForm(request.POST or None, instance=student)
    if form.is_valid():
        form.save()
        return redirect('students-list')
    return render(request, 'students/update_student.html', {
        'student': student,
        'form': form,
    }) 

def students_list(request):
    students = Student.objects.all().order_by('name')
    return render(request, 'students/students_list.html', {
        'students': students,
    })

def show_student(request, student_id):
    student = Student.objects.get(pk=student_id)
    return render(request, 'students/show_student.html', {
        'student': student,
    })

def search_student(request):
    if request.method == "POST":
        searched = request.POST['searched']
        students = Student.objects.filter(name__contains=searched)
        return render(request, 'students/search_student.html', {
            'searched': searched,
            'students': students
        })
    else:
        return render(request, 'students/search_student.html', {})

def delete_student(request, student_id):
    student = Student.objects.get(pk=student_id)
    student.delete()
    return redirect('students-list')

def courses_list(request):
    courses = Coures.objects.all().order_by('course_name')
    return render(request, 'students/courses_list.html', {
        'courses': courses,
    })

def classes_list(request):
    classes = ClassRoom.objects.all().order_by('class_name')
    return render(request, 'students/classes_list.html', {
        'classes': classes,
    })

def delete_course(request, course_id):
    event = Coures.objects.get(pk=course_id)
    event.delete()
    return redirect('courses-list')

def update_course(request, course_id):
    cours = Coures.objects.get(pk=course_id)
    form = CourseForm(request.POST or None, instance=cours)
    if form.is_valid():
        form.save()
        return redirect('courses-list')
    return render(request, 'students/update_course.html', {
        'cours': cours,
        'form': form,
    }) 

def delete_classe(request, classe_id):
    classRoom = ClassRoom.objects.get(pk=classe_id)
    classRoom.delete()
    return redirect('classes-list')

def update_classe(request, classe_id):
    classRoom = ClassRoom.objects.get(pk=classe_id)
    form = ClassRoomForm(request.POST or None, instance=classRoom)
    if form.is_valid():
        form.save()
        return redirect('classes-list')
    return render(request, 'students/update_classe.html', {
        'classRoom': classRoom,
        'form': form,
    }) 




