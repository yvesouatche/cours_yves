from django import forms
from django.forms import ModelForm
from .models import ClassRoom, Coures, Teacher, Student

class ClassRoomForm(ModelForm):
    class Meta:
        model = ClassRoom
        fields= ('class_name', 'description', )

        labels = {
            'class_name': '',  
            'description': '', 
        }

        widgets = {
            'class_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Libélé de la Classe',}),  
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Déscription',}), 
        }

class CourseForm(ModelForm):
    class Meta:
        model = Coures
        fields= ('course_name', 'description', )

        labels = {
            'course_name': '',  
            'description': '', 
        }

        widgets = {
            'course_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Libélé du Cours',}),  
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Déscription',}), 
        }

class TeacherForm(ModelForm):
    class Meta:
        model = Teacher
        fields = ( 'name', 'gender', 'email', 'description', 'classRooms', 'courses', )

        labels = {
            'name': '',  
            'gender': '',    
            'email': '',  
            'description': '',
            'classRooms': 'Selectionner les classes', 
            'courses': 'Selectionner les courses',  
        }

        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nom et Prenom',}),  
            'gender': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Genre',}), 
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Adresse Email',}),  
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Description',}), 
            'classRooms': forms.SelectMultiple(attrs={'class': 'form-select', 'placeholder': 'Choisir les Classes',}), 
            'courses': forms.SelectMultiple(attrs={'class': 'form-control', 'placeholder': 'Choisir les Courses',}), 
        }

class StudentForm(ModelForm):
    class Meta:
        model = Student
        fields = ( 'name', 'gender', 'email', 'classRoom', 'description', 'teachers' , 'courses', )

        labels = {
            'name': '',  
            'gender': '',    
            'email': '',  
            'classRooms': 'Selectionner la classes', 
            'description': '',
            'teachers': 'Selectionner les Enseignants',  
            'courses': 'Selectionner les courses',  
        }

        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nom et Prenom',}),  
            'gender': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Genre',}), 
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Adresse Email',}), 
            'classRooms': forms.Select(attrs={'class': 'form-select', 'placeholder': 'Choisir la Classe',}),  
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Description',}), 
            'teachers': forms.SelectMultiple(attrs={'class': 'form-select', 'placeholder': 'Choisir les Enseignants',}), 
            'courses': forms.SelectMultiple(attrs={'class': 'form-control', 'placeholder': 'Choisir les Courses',}), 
        }
