from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('students_list', views.students_list, name='students-list'),
    path('courses_list', views.courses_list, name='courses-list'),
    path('classes_list', views.classes_list, name='classes-list'),
    path('teachers_list', views.teachers_list, name='teachers-list'),
    path('add_classroom', views.add_classroom, name='add-classroom'),
    path('add_course', views.add_course, name='add-course'),
    path('add_teacher', views.add_teacher, name='add-teacher'),
    path('add_student', views.add_student, name='add-student'),
    path('delete_course/<course_id>', views.delete_course, name='delete-course'),
    path('update_course/<course_id>', views.update_course, name='update-course'),
    path('delete_classe/<classe_id>', views.delete_classe, name='delete-classe'),
    path('update_classe/<classe_id>', views.update_classe, name='update-classe'),
    path('delete_teacher/<teacher_id>', views.delete_teacher, name='delete-teacher'),
    path('update_teacher/<teacher_id>', views.update_teacher, name='update-teacher'),
    path('show_teacher/<teacher_id>', views.show_teacher, name='show-teacher'),

    path('delete_student/<student_id>', views.delete_student, name='delete-student'),
    path('update_student/<student_id>', views.update_student, name='update-student'),
    path('show_student/<student_id>', views.show_student, name='show-student'),
    path('search_student', views.search_student, name='search-student'),
]


